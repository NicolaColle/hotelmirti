# Configurazione della connessione MySQL
db_config = {
    'user': 'hotelmirti',          # Nome utente per il database MySQL
    'password': 'patana14',     # Password per l'utente del database
    'host': 'hotelmirti.mysql.eu.pythonanywhere-services.com',     # L'indirizzo del server MySQL (localhost per server locale)
    'database': 'hotelmirti$default'  # Nome del database a cui connettersi
}
